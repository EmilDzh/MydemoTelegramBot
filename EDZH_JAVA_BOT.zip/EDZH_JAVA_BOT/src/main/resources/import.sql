INSERT INTO users (username, role) VALUES ('test_user_1', 'USER'), ('test_user_2', 'USER'), ('admin_user', 'ADMINISTRATOR');

INSERT INTO subscriptions (group_name, user_id, active, last_article_id) VALUES ('group_name_1', 1, true, 0), ('group_name_2', 1, true, 0), ('group_name_1', 2, true, 0);  -- Для test_user_2


INSERT INTO articles (author, title, description, url, url_to_image, published_at, content, source_id, source_name) VALUES ('Alice Smith', 'AI Innovations', 'Exploring the latest innovations in AI.', 'https://example.com/ai-innovations', 'https://example.com/image-ai.jpg', '2024-09-26', 'In-depth analysis of AI technologies...', 'techcrunch', 'TechCrunch'), ('Bob Johnson', 'Health Trends 2024', 'Latest health trends you should know about.', 'https://example.com/health-trends', 'https://example.com/image-health.jpg', '2024-09-26', 'A comprehensive look at health trends...', 'healthline', 'Healthline'), ('Charlie Brown', 'Space Exploration', 'The future of space exploration.', 'https://example.com/space-exploration', 'https://example.com/image-space.jpg', '2024-09-26', 'An overview of upcoming space missions...', 'nasa', 'NASA'), ('Diana Prince', 'Crypto Insights', 'Understanding the crypto market in 2024.', 'https://example.com/crypto-insights', 'https://example.com/image-crypto.jpg', '2024-09-26', 'A guide to navigating the crypto landscape...', 'coinbase', 'Coinbase');

INSERT INTO subscription_articles (subscription_id, article_id) VALUES (1, 1), (1, 2), (2, 3), (3, 4)
-- (1, 1),  -- Подписка test_user_1 на AI Innovations
-- (1, 2),  -- Подписка test_user_1 на Health Trends 2024
-- (2, 3),  -- Подписка test_user_1 на Space Exploration
-- (3, 4);  -- Подписка test_user_2 на Crypto Insights
