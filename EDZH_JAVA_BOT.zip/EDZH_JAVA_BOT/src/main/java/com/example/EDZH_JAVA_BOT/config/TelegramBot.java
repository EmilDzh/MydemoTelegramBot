package com.example.EDZH_JAVA_BOT.config;

//import org.springframework.stereotype.Component;
//import org.telegram.telegrambots.bots.TelegramLongPollingBot;
//import org.telegram.telegrambots.meta.api.methods.send.SendMessage;
//import org.telegram.telegrambots.meta.api.objects.Update;
//
//@Component
//public class TelegramBot extends TelegramLongPollingBot {
//
//    final BotConfig config;
//
//    public TelegramBot(BotConfig config) {
//        this.config = config;
//    }
//
//
//    @Override
//    public void onUpdateReceived(Update update) {
//
//        if (update.hasMessage() && update.getMessage().hasText()){
//
//            String messageText = update.getMessage().getText();
//            Long chatId = update.getMessage().getChatId();
//
//            switch (messageText){
//
//                case "/start":
//                    startCommandReceived(chatId, update.getMessage().getChat().getFirstName());
//                    break;
//
//                default: sendMessage(chatId, "Sorry command was not recognized");
//            }
//
//        }
//    }
//
//    @Override
//    public String getBotUsername() {
//        return config.botName;
//    }
//
//    @Override
//    public String getBotToken() {
//        return config.botToken;
//    }
//
//    private void startCommandReceived(Long chatId, String name){
//
//        String answer = "Hi, " + name + ", nice to meet you!";
//        sendMessage(chatId,answer);
//    }
//
//    private void sendMessage(Long chatId, String textToSend){
//
//        SendMessage message = new SendMessage();
//        message.setChatId(chatId);
//        message.setText(textToSend);
//
//        try {
//            execute(message);
//        } catch (Exception e){
//            System.err.println(e.getMessage());
//        }
//    }
//}
