package com.example.EDZH_JAVA_BOT.service;

import com.example.EDZH_JAVA_BOT.entity.Subscription;
import com.example.EDZH_JAVA_BOT.entity.User;
import com.example.EDZH_JAVA_BOT.repository.SubscriptionRepository;
import com.example.EDZH_JAVA_BOT.repository.UserRepository;
import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import static com.mysql.cj.conf.PropertyKey.logger;

@Service
public class SubscriptionService {

    @Autowired
    private SubscriptionRepository subscriptionRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ArticleService articleService;

    private static final Logger logger = LoggerFactory.getLogger(SubscriptionService.class);

    public Subscription getSubscriptionById(Long id) {
        return subscriptionRepository.findById(id)
                .orElseThrow(() -> new NoSuchElementException("Подписка с ID " + id + " не найдена."));
    }


    @Transactional
    public void addSubscription(Long chatId, String groupName, String firstName, String lastName) {
        User user = userRepository.findByChatId(chatId)
                .orElseGet(() -> {
                    User newUser = new User();
                    newUser.setChatId(chatId);
                    newUser.setUsername(firstName + " " + (lastName != null ? lastName : ""));
                    return userRepository.save(newUser);
                });

        Subscription subscription = new Subscription();
        subscription.setGroup_name(groupName);
        subscription.setUser(user);

        Long lastArticleId = articleService.getLastArticleIdForGroup(groupName);
        subscription.setLastArticleId(lastArticleId != null ? lastArticleId : 0L);

        subscriptionRepository.save(subscription);
    }

    public List<Subscription> getSubscriptionsByUserId(Long chatId) {
        return subscriptionRepository.findAllByUser_ChatIdAndActiveTrue(chatId);
    }

    public Iterable<Subscription> getAllActiveSubscriptions() {
        Iterable<Subscription> subscriptions = subscriptionRepository.findAll();
        List<Subscription> activeSubs = new ArrayList<>();

        for (Subscription subscription : subscriptions) {
            if (subscription.isActive()) {
                activeSubs.add(subscription);
            }
        }
        return activeSubs;
    }

    public void updateSubscription(Subscription subscription) {
        logger.info("Обновление подписки с ID: {}", subscription.getId());

        Optional<Subscription> existingSubscription = subscriptionRepository.findById(subscription.getId());
        if (existingSubscription.isPresent()) {
            subscriptionRepository.save(subscription);
            logger.info("Подписка успешно обновлена");
        } else {
            logger.error("Подписка с ID {} не найдена", subscription.getId());
            throw new EntityNotFoundException("Подписка не найдена");
        }
    }

    @Transactional
    public void deactivateSubscription(Long chatId, String groupName) {
        Subscription subscription = subscriptionRepository.findByUser_ChatIdAndGroupName(chatId, groupName);
        if (subscription != null && subscription.isActive()) {
            subscription.setActive(false);
            subscriptionRepository.save(subscription);
            logger.info("Подписка на канал '{}' успешно деактивирована.", groupName);
        } else {
            logger.error("Активная подписка на канал '{}' не найдена.", groupName);
            throw new NoSuchElementException("Активная подписка не найдена.");
        }
    }
}
