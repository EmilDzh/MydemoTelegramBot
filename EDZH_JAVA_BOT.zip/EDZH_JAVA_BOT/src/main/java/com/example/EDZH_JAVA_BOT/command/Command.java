package com.example.EDZH_JAVA_BOT.command;

import org.telegram.telegrambots.bots.TelegramLongPollingBot;
import org.telegram.telegrambots.meta.api.objects.Update;

public interface Command {
    void execute(Update update, TelegramLongPollingBot bot);
}
