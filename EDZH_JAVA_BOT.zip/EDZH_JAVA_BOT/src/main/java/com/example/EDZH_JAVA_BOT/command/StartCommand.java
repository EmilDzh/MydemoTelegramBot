package com.example.EDZH_JAVA_BOT.command;

import com.example.EDZH_JAVA_BOT.service.TelegramBotHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.telegram.telegrambots.bots.TelegramLongPollingBot;
import org.telegram.telegrambots.meta.api.methods.send.SendMessage;
import org.telegram.telegrambots.meta.api.objects.Update;

@Component
public class StartCommand implements Command{

    @Override
    public void execute(Update update, TelegramLongPollingBot bot) {
        Long chatId = update.getMessage().getChatId();
        String message = "Привет! Я ваш бот и готов помочь!";

        SendMessage sendMessage = new SendMessage();
        sendMessage.setChatId(chatId);
        sendMessage.setText(message);

        try {
            bot.execute(sendMessage);
        } catch (Exception e){
            System.err.println(e.getMessage());
        }
    }

}
