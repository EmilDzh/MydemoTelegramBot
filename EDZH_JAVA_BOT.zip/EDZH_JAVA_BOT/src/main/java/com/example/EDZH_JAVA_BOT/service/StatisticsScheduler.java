package com.example.EDZH_JAVA_BOT.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class StatisticsScheduler {

    @Autowired
    private StatisticsService statisticsService;

    private static final Logger logger = LoggerFactory.getLogger(StatisticsScheduler.class);

    @Scheduled(cron = "0 */2 * * * *", zone = "Europe/Berlin")
    public void generateDailyStatistics() {
        logger.info("Сбор статистики бота...");
        Map<String, Object> statistics = statisticsService.collectStatistics();

        logger.info("Ежедневная статистика:");
        logger.info("Активные подписки: {}", statistics.get("activeSubs"));
        logger.info("Неактивные подписки: {}", statistics.get("inactiveSubs"));
        logger.info("Среднее количество подписок на пользователя: {}", statistics.get("avgSubscriptions"));
    }
}
