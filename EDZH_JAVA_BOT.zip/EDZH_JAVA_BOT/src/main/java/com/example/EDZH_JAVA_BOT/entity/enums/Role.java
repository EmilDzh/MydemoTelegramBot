package com.example.EDZH_JAVA_BOT.entity.enums;

public enum Role {
    USER,
    ADMINISTRATOR
}
