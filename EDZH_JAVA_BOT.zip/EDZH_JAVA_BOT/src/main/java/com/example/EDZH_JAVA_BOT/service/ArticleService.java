package com.example.EDZH_JAVA_BOT.service;

import com.example.EDZH_JAVA_BOT.entity.Article;
import com.example.EDZH_JAVA_BOT.entity.Subscription;
import com.example.EDZH_JAVA_BOT.newsApi.NewsApiService;
import com.example.EDZH_JAVA_BOT.newsApi.NewsResponse;
import com.example.EDZH_JAVA_BOT.repository.ArticleRepository;
import com.example.EDZH_JAVA_BOT.repository.SubscriptionRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import retrofit2.Call;
import retrofit2.Response;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

@Service
public class ArticleService {

    @Autowired
    private ArticleRepository articleRepository;

    @Autowired
    private NewsApiService newsApiService;

    @Autowired
    private SubscriptionRepository subscriptionRepository;

    // В методе saveArticles
    @Transactional
    public List<Article> saveArticles(List<Article> articles, Subscription subscription) {
        List<Article> uniqueArticles = articles.stream()
                .filter(article -> !articleRepository.existsByUrl(article.getUrl()))
                .limit(5)
                .collect(Collectors.toList());

        System.out.println("Найдено " + uniqueArticles.size() + " уникальных статей для сохранения.");

        if (!uniqueArticles.isEmpty()) {
            List<Article> savedArticles = StreamSupport.stream(articleRepository.saveAll(uniqueArticles).spliterator(), false)
                    .collect(Collectors.toList());
            System.out.println("Сохранено " + savedArticles.size() + " статей.");

            // Обновляем связь подписки с новыми статьями
            subscription.getArticles().addAll(savedArticles);
            for (Article article : savedArticles) {
                if (article.getSubscription() == null) {
                    article.setSubscription(new ArrayList<>()); // Инициализируем список подписок, если он null
                }
                article.getSubscription().add(subscription); // Устанавливаем обратную связь
            }
            subscriptionRepository.save(subscription);

            return savedArticles;
        } else {
            System.out.println("Новых уникальных статей для сохранения не найдено.");
            return Collections.emptyList();
        }
    }


    @Transactional
    public List<Article> fetchNewArticles(String groupName, Long lastArticleId, Subscription subscription) {
        List<Article> newArticles = new ArrayList<>();

        // Получаем текущую дату
        LocalDate currentDate = LocalDate.now();

        // Форматируем дату в нужный формат
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        String formattedDate = currentDate.format(formatter);

        Call<NewsResponse> call = newsApiService.getEverything(
                groupName,
                "2024-11-10", // Измените дату на formattedDate, если это необходимо
                "popularity",
                "c6180ed66aa44cc3beec49a1982e428e"
        );

        try {
            Response<NewsResponse> response = call.execute();

            if (response.isSuccessful() && response.body() != null) {
                System.err.println("Ответ получен: " + response.body().getTotalResults() + " статей.");

                List<Article> articles = response.body().getArticles();
                if (articles != null && !articles.isEmpty()) {
                    System.out.println("Полученные статьи: " + articles.size());
                    for (Article article : articles) {
                        // Проверяем наличие статьи в базе данных по URL, а также её ID
                        if (lastArticleId == null || !articleRepository.existsByUrl(article.getUrl())) {
                            newArticles.add(article);
                        }
                    }

                    // Сохранение только новых статей с привязкой к подписке
                    if (!newArticles.isEmpty()) {
                        newArticles = saveArticles(newArticles, subscription);
                        System.err.println("Найдено и сохранено " + newArticles.size() + " новых статей.");
                    } else {
                        System.err.println("Новых статей не найдено по фильтру.");
                    }
                } else {
                    System.err.println("Полученные статьи пусты.");
                }
            } else {
                System.err.println("Ответ неуспешен. Код: " + response.code());
            }
        } catch (Exception e) {
            System.err.println("Ошибка при получении статей: " + e.getMessage());
            e.printStackTrace();
        }

        return newArticles;
    }

    public Long getLastArticleIdForGroup(String groupName) {
        Subscription subscription = subscriptionRepository.findByGroupName(groupName);
        if (subscription == null || subscription.getArticles().isEmpty()) {
            return null;
        }

        return subscription.getArticles().stream()
                .max(Comparator.comparingLong(Article::getId))
                .map(Article::getId)
                .orElse(null);
    }


}
