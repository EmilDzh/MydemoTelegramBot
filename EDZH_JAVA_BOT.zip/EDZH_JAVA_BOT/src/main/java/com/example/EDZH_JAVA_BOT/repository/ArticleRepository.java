package com.example.EDZH_JAVA_BOT.repository;

import com.example.EDZH_JAVA_BOT.entity.Article;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ArticleRepository extends CrudRepository<Article, Long> {

    boolean existsByUrl(String url);
}
