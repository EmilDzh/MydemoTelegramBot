package com.example.EDZH_JAVA_BOT.newsApi;


//public class Main {
//    public static void main(String[] args) {
//
//        NewsFetcher newsFetcher = new NewsFetcher();
//        newsFetcher.fetchNews();
//    }
//}
