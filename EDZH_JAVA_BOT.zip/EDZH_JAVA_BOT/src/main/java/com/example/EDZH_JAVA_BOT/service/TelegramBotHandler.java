package com.example.EDZH_JAVA_BOT.service;

import com.example.EDZH_JAVA_BOT.command.StartCommand;
import com.example.EDZH_JAVA_BOT.command.StatsCommand;
import com.example.EDZH_JAVA_BOT.command.StopCommand;
import com.example.EDZH_JAVA_BOT.config.BotConfig;
import com.example.EDZH_JAVA_BOT.entity.Subscription;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.telegram.telegrambots.bots.TelegramLongPollingBot;
import org.telegram.telegrambots.meta.api.methods.send.SendMessage;
import org.telegram.telegrambots.meta.api.objects.Update;

import java.util.List;
import java.util.NoSuchElementException;

@Component
public class TelegramBotHandler extends TelegramLongPollingBot {

    @Autowired
    private BotConfig botConfig;

    private static final Logger logger = LoggerFactory.getLogger(TelegramBotHandler.class);

    @Autowired
    public TelegramBotHandler(BotConfig botConfig, SubscriptionService subscriptionService, StartCommand startCommand, StopCommand stopCommand, StatsCommand statsCommand) {
        this.botConfig = botConfig;
        this.subscriptionService = subscriptionService;
        this.startCommand = startCommand;
        this.stopCommand = stopCommand;
        this.statsCommand = statsCommand;
    }

    @Autowired
    private SubscriptionService subscriptionService;

    @Autowired
    private StartCommand startCommand;

    @Autowired
    private StopCommand stopCommand;

    @Autowired
    private StatsCommand statsCommand;


    @Override
    public void onUpdateReceived(Update update) {

        if (update.hasMessage() && update.getMessage().hasText()) {
            String messageText = update.getMessage().getText();
            Long chatId = update.getMessage().getChatId();
            String firstName = update.getMessage().getFrom().getFirstName();
            String lastName = update.getMessage().getFrom().getLastName();

            if (messageText.startsWith("/addChannelSub")) {
                handleAddChannelSub(chatId, messageText, firstName, lastName);
            } else if (messageText.startsWith("/listChannelSub")) {
                handleListChannelSub(chatId);
            } else if (messageText.startsWith("/removeChannelSub")) {
                handleRemoveChannelSub(chatId, messageText);
            } else if (messageText.startsWith("/start")) {
                startCommand.execute(update, this);
            } else if (messageText.startsWith("/stop")) {
                stopCommand.execute(update, this);
            } else if (messageText.startsWith("/stats")) {
                statsCommand.execute(update, this);
            }
        }
    }

    @Override
    public String getBotUsername() {
        return botConfig.botName;
    }

    private void handleAddChannelSub(Long chatId, String messageText, String firstName, String lastName) {

        String[] parts = messageText.split(" ", 2);

        if (parts.length < 2) {
            sendMessage(chatId, "Пожалуйста, укажите название канала для подписки.");
            return;
        }

        String groupName = parts[1];

        subscriptionService.addSubscription(chatId, groupName, firstName, lastName);

        sendMessage(chatId, "Вы успешно подписались на канал: " + groupName);
    }

    private void handleListChannelSub(Long chatId) {

        List<Subscription> subscriptions = subscriptionService.getSubscriptionsByUserId(chatId);

        if (subscriptions.isEmpty()) {
            sendMessage(chatId, "У вас нет активных подписок.");
        } else {
            StringBuilder respone = new StringBuilder("Ваши подписки:\n");
            for (Subscription subscription : subscriptions) {
                respone.append("Канал: ").append(subscription.getGroup_name())
                        .append(", Последняя статья ID: ").append(subscription.getLastArticleId())
                        .append("\n");

            }
            sendMessage(chatId, respone.toString());

        }
    }

    public void sendMessage(Long chatId, String text) {
        if (chatId == null || text == null) {
            logger.error("chatId или текст сообщения не должны быть null");
            return;
        }

        SendMessage message = new SendMessage();
        message.setChatId(chatId);
        message.setText(text);

        try {
            execute(message);
        } catch (Exception e) {
            logger.error("Ошибка при отправке сообщения в Telegram: {}", e.getMessage());
        }
    }

    @Override
    public String getBotToken() {
        return botConfig.botToken;
    }

    private void handleRemoveChannelSub(Long chatId, String messageText) {
        String[] parts = messageText.split(" ", 2);

        if (parts.length < 2) {
            sendMessage(chatId, "Пожалуйста, укажите название канала для удаления подписки.");
            return;
        }

        String groupName = parts[1];

        try {
            subscriptionService.deactivateSubscription(chatId, groupName);
            sendMessage(chatId, "Подписка на канал '" + groupName + "' успешно деактивирована.");
        } catch (NoSuchElementException e) {
            sendMessage(chatId, "Активная подписка на канал '" + groupName + "' не найдена.");
        }

    }


}
