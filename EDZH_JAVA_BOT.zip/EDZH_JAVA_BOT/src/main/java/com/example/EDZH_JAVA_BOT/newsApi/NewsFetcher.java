package com.example.EDZH_JAVA_BOT.newsApi;

import com.example.EDZH_JAVA_BOT.entity.Article;
import com.example.EDZH_JAVA_BOT.service.ArticleService;
import org.springframework.beans.factory.annotation.Autowired;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

//public class NewsFetcher {
//
//    @Autowired
//    private ArticleService articleService;
//
//    public void fetchNews() {
//        String today = LocalDate.now().format(DateTimeFormatter.ISO_LOCAL_DATE);
//        NewsApiService service = RetrofitClient.create();
//        Call<NewsResponse> call = service.getEverything(
//                "apple",
//                "2024-09-23",
//                "popularity",
//                "c6180ed66aa44cc3beec49a1982e428e"
//        );
//
//        call.enqueue(new Callback<NewsResponse>() {
//            @Override
//            public void onResponse(Call<NewsResponse> call, Response<NewsResponse> response) {
//                if (response.isSuccessful() && response.body() != null) {
//                    List<Article> articles = response.body().getArticles();
//                    if (articles != null && !articles.isEmpty()) {
//                        // Сохраняем статьи в базу данных
//                        articleService.saveArticles(articles);
//                        System.out.println("Articles successfully saved to the database.");
//                    } else {
//                        System.out.println("No articles found.");
//                    }
//                } else {
//                    System.out.println("Response was not successful. Code: " + response.code());
//                }
//            }
//
//            @Override
//            public void onFailure(Call<NewsResponse> call, Throwable throwable) {
//                System.err.println("Error occurred: " + throwable.getMessage());
//            }
//        });
//    }
//}
