package com.example.EDZH_JAVA_BOT.command;

import com.example.EDZH_JAVA_BOT.entity.User;
import com.example.EDZH_JAVA_BOT.repository.UserRepository;
import com.example.EDZH_JAVA_BOT.service.StatisticsService;
import com.example.EDZH_JAVA_BOT.service.TelegramBotHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.telegram.telegrambots.bots.TelegramLongPollingBot;
import org.telegram.telegrambots.meta.api.methods.send.SendMessage;
import org.telegram.telegrambots.meta.api.objects.Update;

import java.util.Map;

@Component
public class StatsCommand implements Command {

    private static final Logger logger = LoggerFactory.getLogger(StatsCommand.class);

    @Autowired
    private StatisticsService statisticsService;

    @Autowired
    private UserRepository userRepository;

    @Override
    public void execute(Update update, TelegramLongPollingBot bot) {

        Long chatId = update.getMessage().getChatId();
        String message = "У вас нет прав для выполнения этой команды.";

        SendMessage sendMessage = new SendMessage();
        sendMessage.setChatId(chatId);
        sendMessage.setText(message);

        User user = userRepository.findByChatId(chatId).orElse(null);
        if (user == null || !user.getRole().equals("ADMINISTRATOR")) {
            try {
                bot.execute(sendMessage);
            } catch (Exception e){
                logger.error(e.getMessage());
            }
            return;
        }

        Map<String, Object> statistics = statisticsService.collectStatistics();
        String response = String.format(
                "Статистика бота:\n" +
                        "- Активные пользователи: %d\n" +
                        "- Неактивные пользователи: %d\n" +
                        "- Среднее количество подписок: %.2f",
                statistics.get("activeUsers"),
                statistics.get("inactiveUsers"),
                statistics.get("avgSubscriptions")
        );

        sendMessage.setText(response);

        try {
            bot.execute(sendMessage);
        } catch (Exception e){
            logger.error(e.getMessage());
        }

    }


}
