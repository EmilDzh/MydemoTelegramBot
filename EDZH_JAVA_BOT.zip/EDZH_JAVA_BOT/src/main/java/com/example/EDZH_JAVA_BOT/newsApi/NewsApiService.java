package com.example.EDZH_JAVA_BOT.newsApi;

import org.springframework.stereotype.Service;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

/*
curl https://newsapi.org/v2/everything -G \
    -d q=Apple \
    -d from=2024-09-23 \
    -d sortBy=popularity \
    -d apiKey=c6180ed66aa44cc3beec49a1982e428e
*/

public interface NewsApiService {

    @GET("v2/everything")
    Call<NewsResponse> getEverything(
            @Query("q")String query,
            @Query("from")String fromDate,
            @Query("sortBy")String sortBy,
            @Query("apiKey")String apiKey
    );
}
