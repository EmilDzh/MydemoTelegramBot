package com.example.EDZH_JAVA_BOT.service;

import com.example.EDZH_JAVA_BOT.entity.Article;
import com.example.EDZH_JAVA_BOT.entity.Subscription;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.List;

@Service
public class NotificationScheduler {

    @Autowired
    private SubscriptionService subscriptionService;

    @Autowired
    private ArticleService articleService;

    @Autowired
    private TelegramBotHandler telegramBotHandler;

    @Scheduled(cron = "0 */2 * * * *", zone = "Europe/Berlin")
    public void notifySubscribers() {
        System.out.println("Запуск уведомлений подписчикам...");

        Iterable<Subscription> subscriptions = subscriptionService.getAllActiveSubscriptions();
        for (Subscription subscription : subscriptions) {
            System.out.println("Проверка новых статей для подписки: " + subscription.getGroup_name());

            try {
                // Находим новые статьи, которые еще не сохранены
                List<Article> newArticles = articleService.fetchNewArticles(subscription.getGroup_name(), subscription.getLastArticleId(), subscription);
                System.out.println("Найдено " + newArticles.size() + " новых статей.");

                // Если статьи есть, отправляем их пользователю и сохраняем
                if (!newArticles.isEmpty()) {
                    for (Article article : newArticles) {
                        telegramBotHandler.sendMessage(subscription.getUser().getChatId(),
                                "Новая статья: " + article.getTitle() + "\n" + article.getUrl());
                    }

                    // Обновляем lastArticleId для подписки после отправки статей
                    subscription.setLastArticleId(newArticles.get(newArticles.size() - 1).getId());
                    subscriptionService.updateSubscription(subscription);
                } else {
                    System.out.println("Новых статей не найдено для подписки " + subscription.getGroup_name());
                }
            } catch (Exception e) {
                System.err.println("Ошибка при уведомлении подписчиков: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }
}
