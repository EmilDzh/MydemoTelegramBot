package com.example.EDZH_JAVA_BOT.repository;

import com.example.EDZH_JAVA_BOT.entity.Subscription;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SubscriptionRepository extends CrudRepository<Subscription, Long> {
    List<Subscription> findAllByUser_ChatId(Long chatId);
    Subscription findByGroupName(String groupName);

    List<Subscription> findAllByUser_ChatIdAndActiveTrue(Long chatId);

    Subscription findByUser_ChatIdAndGroupName(Long chatId, String groupName);

    @Query("SELECT AVG(subscriptionCount) FROM (SELECT COUNT(s.id) as subscriptionCount FROM Subscription s GROUP BY s.user) subquery")
    Double calculateAverageSubscriptionsPerUser();

    // Подсчет активных пользователей
    long countByActive(boolean active);
}
