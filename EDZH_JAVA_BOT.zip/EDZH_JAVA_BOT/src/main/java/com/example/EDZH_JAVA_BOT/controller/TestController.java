package com.example.EDZH_JAVA_BOT.controller;

import com.example.EDZH_JAVA_BOT.entity.Subscription;
import com.example.EDZH_JAVA_BOT.service.ArticleService;
import com.example.EDZH_JAVA_BOT.service.SubscriptionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import retrofit2.Response;

@RestController
public class TestController {

    @Autowired
    private ArticleService articleService;

    @Autowired
    private SubscriptionService subscriptionService;

    @GetMapping("test/fetch/news")
    public ResponseEntity<String> TestFetchNewArticles(){
        Subscription subscription = subscriptionService.getSubscriptionById(1L);
        articleService.fetchNewArticles("news", null, subscription);
        return ResponseEntity.ok("Тестирование TestFetchNewArticles запущено.");
    }

}
