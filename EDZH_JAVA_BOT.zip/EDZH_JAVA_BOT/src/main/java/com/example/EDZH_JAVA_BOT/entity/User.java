package com.example.EDZH_JAVA_BOT.entity;

import com.example.EDZH_JAVA_BOT.entity.enums.Role;
import jakarta.persistence.*;


import java.util.List;

@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id;

    String username;

    @Enumerated(EnumType.STRING)
    Role role;

    @Column(unique = true)
    private Long chatId;

    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
    public List<Subscription> subscription;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public Long getChatId() {
        return chatId;
    }

    public void setChatId(Long chatId) {
        this.chatId = chatId;
    }

    public List<Subscription> getSubscription() {
        return subscription;
    }

    public void setSubscription(List<Subscription> subscription) {
        this.subscription = subscription;
    }
}
