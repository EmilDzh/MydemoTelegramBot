package com.example.EDZH_JAVA_BOT.service;

import com.example.EDZH_JAVA_BOT.repository.SubscriptionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class StatisticsService {

    @Autowired
    private SubscriptionRepository subscriptionRepository;

    public Map<String, Object> collectStatistics() {
        Map<String, Object> statistics = new HashMap<>();

        long activeSubs = subscriptionRepository.countByActive(true);
        statistics.put("activeSubs", activeSubs);

        long inactiveSubs = subscriptionRepository.countByActive(false);
        statistics.put("inactiveSubs", inactiveSubs);

        double avgSubscriptions = subscriptionRepository.calculateAverageSubscriptionsPerUser();
        statistics.put("avgSubscriptions", avgSubscriptions);

        return statistics;

    }
}
